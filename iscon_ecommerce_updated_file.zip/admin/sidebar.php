<div class="section-menu-left">
                    <div class="box-logo">
                        <a href="index-2.html" id="site-logo-inner">
                            <img class="img-fluid " id="logo_header" alt="" src="images/ISKCON_Logo.png" data-light="images/ISKCON_Logo.png" data-dark="images/ISKCON_Logo.png" width="100"  height="100">
                        </a>
                        <div class="button-show-hide">
                            <i class="icon-menu-left"></i>
                        </div>
                    </div>
                    <div class="section-menu-left-wrap">
                        <div class="center">
                            <div class="center-item">
                                <div class="center-heading">Main Home</div>
                                <ul class="menu-list">
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-grid"></i></div>
                                            <div class="text">Dashboard</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="index-2.html" class="">
                                                    <div class="text">Home 01</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="home-2.html" class="">
                                                    <div class="text">Home 02</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="home-3.html" class="">
                                                    <div class="text">Home 03</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="home-4.html" class="">
                                                    <div class="text">Home 04</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="home-boxed.html" class="">
                                                    <div class="text">Home Boxed</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="home-menu-icon-hover.html" class="">
                                                    <div class="text">Home Menu Icon Hover</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="home-menu-icon-default.html" class="">
                                                    <div class="text">Home Menu Icon Default</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="center-item">
                                <div class="center-heading">All page</div>
                                <ul class="menu-list">
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-shopping-cart"></i></div>
                                            <div class="text">Ecommerce</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="add-product.php" class="">
                                                    <div class="text">Add Product</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="product-list.php" class="">
                                                    <div class="text">Product List</div>
                                                </a>
                                            </li>
                                            <!-- <li class="sub-menu-item">
                                                <a href="product-detail-1.html" class="">
                                                    <div class="text">Product Detail 1</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="product-detail-2.html" class="">
                                                    <div class="text">Product Detail 2</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="product-detail-3.html" class="">
                                                    <div class="text">Product Detail 3</div>
                                                </a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <li class="menu-item has-children ">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-layers"></i></div>
                                            <div class="text">Category</div>
                                        </a>
                                        <ul class="sub-menu" style="display: block;">
                                            <li class="sub-menu-item">
                                                <a href="category-list.php" class="">
                                                    <div class="text">Category list</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="new-category.php" class="">
                                                    <div class="text">Add Main category</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="subcategories.php" class="">
                                                    <div class="text">Add Sub category</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-box"></i></div>
                                            <div class="text">Blogs</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="blog.php" class="">
                                                    <div class="text">Blogs</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="add-blog.php" class="">
                                                    <div class="text">Add Blogs</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-file-plus"></i></div>
                                            <div class="text">Order</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="oder-list.php" class="">
                                                    <div class="text">Order list</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="oder-detail.php" class="">
                                                    <div class="text">Order detail</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="oder-tracking.php" class="">
                                                    <div class="text">Order tracking</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-user"></i></div>
                                            <div class="text">User</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="all-user.php" class="">
                                                    <div class="text">All user</div>
                                                </a>
                                            </li>
                                            <!-- <li class="sub-menu-item">
                                                <a href="add-new-user.php" class="">
                                                    <div class="text">Add new user</div>
                                                </a>
                                            </li> -->
                                            <!-- <li class="sub-menu-item">
                                                <a href="login.php" class="">
                                                    <div class="text">Login</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="sign-up.php" class="">
                                                    <div class="text">Sign up</div>
                                                </a>
                                            </li> -->
                                        </ul>
                                    </li>
                                    <!-- <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-user-plus"></i></div>
                                            <div class="text">Roles</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="all-roles.html" class="">
                                                    <div class="text">All roles</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="create-role.html" class="">
                                                    <div class="text">Create role</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li> -->
                                    <li class="menu-item">
                                        <a href="gallery.php" class="">
                                            <div class="icon"><i class="icon-image"></i></div>
                                            <div class="text">Gallery</div>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a href="report.php" class="">
                                            <div class="icon"><i class="icon-pie-chart"></i></div>
                                            <div class="text">Report</div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="center-item">
                                <div class="center-heading">Setting</div>
                                <ul class="menu-list">
                                   
                                    <li class="menu-item">
                                        <a href="setting.php" class="">
                                            <div class="icon"><i class="icon-settings"></i></div>
                                            <div class="text">Setting</div>
                                        </a>
                                    </li>
                                    <!-- <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-edit"></i></div>
                                            <div class="text">Pages</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="list-page.html" class="">
                                                    <div class="text">List page</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="new-page.html" class="">
                                                    <div class="text">New page</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="edit-page.html" class="">
                                                    <div class="text">Edit page</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li> -->
                                </ul>
                            </div>
                        
                        
                            
                        </div>
                       
                    </div>
                </div>